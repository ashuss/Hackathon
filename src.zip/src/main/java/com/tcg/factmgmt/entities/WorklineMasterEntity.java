package com.tcg.factmgmt.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "WORKLINE_MASTER")
public class WorklineMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "WORKLINE_ID")
	private String workLine_Id;

//	@Column(name = "PLANT_ID")
//	private String plant_Id;

	@Column(name = "WORKLINE_DESC")
	private String workLine_Desc;

	@OneToMany(mappedBy = "worklineMasterEntity", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<SubstageMasterEntity> substageDetailsEntity;

	@ManyToOne
	@JoinColumn(name = "PLANT_ID", referencedColumnName = "PLANT_ID")
	@JsonIgnore
	private PlantMasterEntity plantMasterEntity;

	public String getWorkLine_Id() {
		return workLine_Id;
	}

	public void setWorkLine_Id(String workLine_Id) {
		this.workLine_Id = workLine_Id;
	}

//	public String getPlant_Id() {
//		return plant_Id;
//	}
//
//	public void setPlant_Id(String plant_Id) {
//		this.plant_Id = plant_Id;
//	}

	public String getWorkLine_Desc() {
		return workLine_Desc;
	}

	public void setWorkLine_Desc(String workLine_Desc) {
		this.workLine_Desc = workLine_Desc;
	}

	public PlantMasterEntity getPlantMasterEntity() {
		return plantMasterEntity;
	}

	public void setPlantMasterEntity(PlantMasterEntity plantMasterEntity) {
		this.plantMasterEntity = plantMasterEntity;
	}

	public List<SubstageMasterEntity> getSubstageDetailsEntity() {
		return substageDetailsEntity;
	}

	public void setSubstageDetailsEntity(List<SubstageMasterEntity> substageDetailsEntity) {
		this.substageDetailsEntity = substageDetailsEntity;
	}

}
