package com.tcg.factmgmt.entities;

import java.security.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ASSET_TRACKING_MASTER")
public class AssetTrackingTransactionalEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ASSET_TRACKING_ID")
	private String assetTracking_Id;

//	@Column(name = "SUBSTAGE_ID")
//	private String substage_Id;

	@Column(name = "ACTUAL_IN_TIME")
	private Timestamp actual_In_Time;

	@Column(name = "ACTUAL_OUT_TIME")
	private Timestamp actual_Out_Time;

	@Column(name = "OPERATION_START_TIME")
	private Timestamp operation_Start_time;

	@Column(name = "OPERATION_END_TIME")
	private Timestamp operation_End_time;

	@Column(name = "ACTUAL_TO_SUBSTAGE_TIME")
	private Timestamp actual_To_SubStage_Time;

	@Column(name = "SUBSTAGE_EFFICIENCY")
	private float subStage_Efficiency;

	@Column(name = "OPERATOR_EFFICIENCY")
	private float operator_Efficiency;

//	@Column(name = "OPERATOR_ID")
//	private String operatorId;

	@ManyToOne
	@JoinColumn(name = "SUBSTAGE_ID", referencedColumnName = "SUBSTAGE_ID")
	@JsonIgnore
	private SubstageMasterEntity subStageMasterEntity;
	
	@ManyToOne
	@JoinColumn(name = "OPERATOR_ID", referencedColumnName = "OPERATOR_ID")
	@JsonIgnore
	private OperatorMasterEntity operatorMasterEntity;
	
	@ManyToOne
	@JoinColumn(name = "ASSET_ID", referencedColumnName = "ASSET_ID")
	@JsonIgnore
	private AssetMasterEntity assetMasterEntity;

	public String getAssetTracking_Id() {
		return assetTracking_Id;
	}

	public void setAssetTracking_Id(String assetTracking_Id) {
		this.assetTracking_Id = assetTracking_Id;
	}

	

//	public String getSubstage_Id() {
//		return substage_Id;
//	}
//
//	public void setSubstage_Id(String substage_Id) {
//		this.substage_Id = substage_Id;
//	}

	public Timestamp getActual_In_Time() {
		return actual_In_Time;
	}

	public void setActual_In_Time(Timestamp actual_In_Time) {
		this.actual_In_Time = actual_In_Time;
	}

	public Timestamp getActual_Out_Time() {
		return actual_Out_Time;
	}

	public void setActual_Out_Time(Timestamp actual_Out_Time) {
		this.actual_Out_Time = actual_Out_Time;
	}

	public Timestamp getOperation_Start_time() {
		return operation_Start_time;
	}

	public void setOperation_Start_time(Timestamp operation_Start_time) {
		this.operation_Start_time = operation_Start_time;
	}

	public Timestamp getOperation_End_time() {
		return operation_End_time;
	}

	public void setOperation_End_time(Timestamp operation_End_time) {
		this.operation_End_time = operation_End_time;
	}

	public Timestamp getActual_To_SubStage_Time() {
		return actual_To_SubStage_Time;
	}

	public void setActual_To_SubStage_Time(Timestamp actual_To_SubStage_Time) {
		this.actual_To_SubStage_Time = actual_To_SubStage_Time;
	}

	public float getSubStage_Efficiency() {
		return subStage_Efficiency;
	}

	public void setSubStage_Efficiency(float subStage_Efficiency) {
		this.subStage_Efficiency = subStage_Efficiency;
	}

	public float getOperator_Efficiency() {
		return operator_Efficiency;
	}

	public void setOperator_Efficiency(float operator_Efficiency) {
		this.operator_Efficiency = operator_Efficiency;
	}

//	public String getOperatorId() {
//		return operatorId;
//	}
//
//	public void setOperatorId(String operatorId) {
//		this.operatorId = operatorId;
//	}

	public SubstageMasterEntity getSubStageMasterEntity() {
		return subStageMasterEntity;
	}

	public void setSubStageMasterEntity(SubstageMasterEntity subStageMasterEntity) {
		this.subStageMasterEntity = subStageMasterEntity;
	}

	public OperatorMasterEntity getOperatorMasterEntity() {
		return operatorMasterEntity;
	}

	public void setOperatorMasterEntity(OperatorMasterEntity operatorMasterEntity) {
		this.operatorMasterEntity = operatorMasterEntity;
	}

	public AssetMasterEntity getAssetMasterEntity() {
		return assetMasterEntity;
	}

	public void setAssetMasterEntity(AssetMasterEntity assetMasterEntity) {
		this.assetMasterEntity = assetMasterEntity;
	}

}
