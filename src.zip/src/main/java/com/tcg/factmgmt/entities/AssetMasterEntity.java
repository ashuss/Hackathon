package com.tcg.factmgmt.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ASSET_MASTER")
public class AssetMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ASSET_ID")
	private String asset_Id;

	@Column(name = "ASSET_NAME")
	private String asset_Name;

	@OneToMany(mappedBy = "assetMasterEntity1", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AssetSubstageMasterEntity> assetSubstageMasterEntity;

	@OneToMany(mappedBy = "assetMasterEntity", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AssetTrackingTransactionalEntity> sssetTrackingTransactionalEntity;

	public String getAsset_Id() {
		return asset_Id;
	}

	public void setAsset_Id(String asset_Id) {
		this.asset_Id = asset_Id;
	}

	public String getAsset_Name() {
		return asset_Name;
	}

	public void setAsset_Name(String asset_Name) {
		this.asset_Name = asset_Name;
	}

	public List<AssetSubstageMasterEntity> getAssetSubstageMasterEntity() {
		return assetSubstageMasterEntity;
	}

	public void setAssetSubstageMasterEntity(List<AssetSubstageMasterEntity> assetSubstageMasterEntity) {
		this.assetSubstageMasterEntity = assetSubstageMasterEntity;
	}

	public List<AssetTrackingTransactionalEntity> getSssetTrackingTransactionalEntity() {
		return sssetTrackingTransactionalEntity;
	}

	public void setSssetTrackingTransactionalEntity(
			List<AssetTrackingTransactionalEntity> sssetTrackingTransactionalEntity) {
		this.sssetTrackingTransactionalEntity = sssetTrackingTransactionalEntity;
	}

}
