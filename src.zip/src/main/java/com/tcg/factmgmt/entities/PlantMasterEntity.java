package com.tcg.factmgmt.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "PLANT_MASTER")
public class PlantMasterEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PLANT_ID")
	private String plant_Id;
	
	@Column(name = "PLANT_NAME")
	private String plant_Name;
	
	@Column(name = "LATITUDE")
	private String latitude;
	
	@Column(name = "LONGITUDE")
	private String longitude;
	
	@OneToMany(mappedBy = "plantMasterEntity", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<WorklineMasterEntity> worklineDetailsEntity;

	public String getPlant_Id() {
		return plant_Id;
	}

	public void setPlant_Id(String plant_Id) {
		this.plant_Id = plant_Id;
	}

	public String getPlant_Name() {
		return plant_Name;
	}

	public void setPlant_Name(String plant_Name) {
		this.plant_Name = plant_Name;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public List<WorklineMasterEntity> getWorklineDetailsEntity() {
		return worklineDetailsEntity;
	}

	public void setWorklineDetailsEntity(List<WorklineMasterEntity> worklineDetailsEntity) {
		this.worklineDetailsEntity = worklineDetailsEntity;
	}
	
	

}
