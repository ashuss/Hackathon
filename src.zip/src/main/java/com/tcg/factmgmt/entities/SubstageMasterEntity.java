package com.tcg.factmgmt.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "SUBSTAGE_MASTER")
public class SubstageMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SUBSTAGE_ID")
	private String substage_Id;

//	@Column(name = "WORKLINE_ID")
//	private String workLine_Id;

	@Column(name = "SUBSTAGE_DESC")
	private String substage_Desc;

	@Column(name = "STAGE_ID")
	private String stage_Id;

	@OneToMany(mappedBy = "subStageMasterEntity", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AssetTrackingTransactionalEntity> assetTrackingTransactionalEntity;
	
	@OneToMany(mappedBy = "subStageMasterEntity1", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AssetSubstageMasterEntity> assetSubstageMasterEntity;
	
	@ManyToOne
	@JoinColumn(name = "WORKLINE_ID", referencedColumnName = "WORKLINE_ID")
	@JsonIgnore
	private WorklineMasterEntity worklineMasterEntity;

	public String getSubstage_Id() {
		return substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		this.substage_Id = substage_Id;
	}

//	public String getWorkLine_Id() {
//		return workLine_Id;
//	}
//
//	public void setWorkLine_Id(String workLine_Id) {
//		this.workLine_Id = workLine_Id;
//	}

	public String getSubstage_Desc() {
		return substage_Desc;
	}

	public void setSubstage_Desc(String substage_Desc) {
		this.substage_Desc = substage_Desc;
	}

	public String getStage_Id() {
		return stage_Id;
	}

	public void setStage_Id(String stage_Id) {
		this.stage_Id = stage_Id;
	}

	public WorklineMasterEntity getWorklineMasterEntity() {
		return worklineMasterEntity;
	}

	public void setWorklineMasterEntity(WorklineMasterEntity worklineMasterEntity) {
		this.worklineMasterEntity = worklineMasterEntity;
	}

	public List<AssetTrackingTransactionalEntity> getAssetTrackingTransactionalEntity() {
		return assetTrackingTransactionalEntity;
	}

	public void setAssetTrackingTransactionalEntity(
			List<AssetTrackingTransactionalEntity> assetTrackingTransactionalEntity) {
		this.assetTrackingTransactionalEntity = assetTrackingTransactionalEntity;
	}

}
