package com.tcg.factmgmt.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "OPERATOR_MASTER")
public class OperatorMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "OPERATOR_ID")
	private String operatorId;

	@Column(name = "STAGE_ID")
	private String stage_Id;

	@Column(name = "SUBSTAGE_ID")
	private String substage_Id;

	@Column(name = "OPERATOR_NAME")
	private String operatorName;

	@Column(name = "OPERATOR_CONTACT")
	private String operatorContact;

	@Column(name = "OPERATOR_SHIFT")
	private String operatorShift;

	@OneToMany(mappedBy = "operatorMasterEntity", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<AssetTrackingTransactionalEntity> assetTrackingTransactionalEntity;

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getStage_Id() {
		return stage_Id;
	}

	public void setStage_Id(String stage_Id) {
		this.stage_Id = stage_Id;
	}

	public String getSubstage_Id() {
		return substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		this.substage_Id = substage_Id;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getOperatorContact() {
		return operatorContact;
	}

	public void setOperatorContact(String operatorContact) {
		this.operatorContact = operatorContact;
	}

	public String getOperatorShift() {
		return operatorShift;
	}

	public void setOperatorShift(String operatorShift) {
		this.operatorShift = operatorShift;
	}

	public List<AssetTrackingTransactionalEntity> getAssetTrackingTransactionalEntity() {
		return assetTrackingTransactionalEntity;
	}

	public void setAssetTrackingTransactionalEntity1(
			List<AssetTrackingTransactionalEntity> assetTrackingTransactionalEntity) {
		this.assetTrackingTransactionalEntity = assetTrackingTransactionalEntity;
	}

}
