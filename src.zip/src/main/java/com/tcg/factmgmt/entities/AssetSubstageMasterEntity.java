package com.tcg.factmgmt.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ASSET_SUBSTAGE_MASTER")
public class AssetSubstageMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ASSET_SUBSTAGE_ID")
	private String AssetSubstage_Id;

//	@Column(name = "ASSET_ID")
//	private String Asset_Id;
//
//	@Column(name = "SUBSTAGE_ID")
//	private String Substage_Id;

	@Column(name = "IDEAL_SUBSATGE_TIME")
	private float Ideal_Time_SubStage;

	@Column(name = "OPERATOR_BUFFER_TIME")
	private float Operator_Buffer_Time;

	@Column(name = "IDEAL_TIME_TO_SUBSTAGE")
	private float Ideal_Time_To_SubStage;

	@ManyToOne
	@JoinColumn(name = "SUBSTAGE_ID", referencedColumnName = "SUBSTAGE_ID")
	@JsonIgnore
	private SubstageMasterEntity subStageMasterEntity1;
	
	@ManyToOne
	@JoinColumn(name = "ASSET_ID", referencedColumnName = "ASSET_ID")
	@JsonIgnore
	private AssetMasterEntity assetMasterEntity1;

	public String getAssetSubstage_Id() {
		return AssetSubstage_Id;
	}

	public void setAssetSubstage_Id(String assetSubstage_Id) {
		AssetSubstage_Id = assetSubstage_Id;
	}

//	public String getAsset_Id() {
//		return Asset_Id;
//	}
//
//	public void setAsset_Id(String asset_Id) {
//		Asset_Id = asset_Id;
//	}
//
//	public String getSubstage_Id() {
//		return Substage_Id;
//	}
//
//	public void setSubstage_Id(String substage_Id) {
//		Substage_Id = substage_Id;
//	}

	public float getIdeal_Time_SubStage() {
		return Ideal_Time_SubStage;
	}

	public void setIdeal_Time_SubStage(float ideal_Time_SubStage) {
		Ideal_Time_SubStage = ideal_Time_SubStage;
	}

	public float getOperator_Buffer_Time() {
		return Operator_Buffer_Time;
	}

	public void setOperator_Buffer_Time(float operator_Buffer_Time) {
		Operator_Buffer_Time = operator_Buffer_Time;
	}

	public float getIdeal_Time_To_SubStage() {
		return Ideal_Time_To_SubStage;
	}

	public void setIdeal_Time_To_SubStage(float ideal_Time_To_SubStage) {
		Ideal_Time_To_SubStage = ideal_Time_To_SubStage;
	}

	public SubstageMasterEntity getSubStageMasterEntity1() {
		return subStageMasterEntity1;
	}

	public void setSubStageMasterEntity1(SubstageMasterEntity subStageMasterEntity1) {
		this.subStageMasterEntity1 = subStageMasterEntity1;
	}

	public AssetMasterEntity getAssetMasterEntity() {
		return assetMasterEntity1;
	}

	public void setAssetMasterEntity(AssetMasterEntity assetMasterEntity1) {
		this.assetMasterEntity1 = assetMasterEntity1;
	}
	
	

}
