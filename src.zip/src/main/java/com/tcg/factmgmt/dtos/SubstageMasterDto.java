package com.tcg.factmgmt.dtos;

public class SubstageMasterDto {

	private String substage_Id;
	private String workLine_Id;
	private String substage_Desc;
	private String stage_Id;

	public String getSubstage_Id() {
		return substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		this.substage_Id = substage_Id;
	}

	public String getWorkLine_Id() {
		return workLine_Id;
	}

	public void setWorkLine_Id(String workLine_Id) {
		this.workLine_Id = workLine_Id;
	}

	public String getSubstage_Desc() {
		return substage_Desc;
	}

	public void setSubstage_Desc(String substage_Desc) {
		this.substage_Desc = substage_Desc;
	}

	public String getStage_Id() {
		return stage_Id;
	}

	public void setStage_Id(String stage_Id) {
		this.stage_Id = stage_Id;
	}

}
