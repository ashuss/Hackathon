package com.tcg.factmgmt.dtos;

public class AssetMasterDto {

	private String asset_Id;
	private String asset_Name;

	public String getAsset_Id() {
		return asset_Id;
	}

	public void setAsset_Id(String asset_Id) {
		this.asset_Id = asset_Id;
	}

	public String getAsset_Name() {
		return asset_Name;
	}

	public void setAsset_Name(String asset_Name) {
		this.asset_Name = asset_Name;
	}

}
