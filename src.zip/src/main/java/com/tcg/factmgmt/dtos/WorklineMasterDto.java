package com.tcg.factmgmt.dtos;

public class WorklineMasterDto {

	private String workLine_Id;
	private String plant_Id;
	private String workLine_Desc;

	public String getWorkLine_Id() {
		return workLine_Id;
	}

	public void setWorkLine_Id(String workLine_Id) {
		this.workLine_Id = workLine_Id;
	}

	public String getPlant_Id() {
		return plant_Id;
	}

	public void setPlant_Id(String plant_Id) {
		this.plant_Id = plant_Id;
	}

	public String getWorkLine_Desc() {
		return workLine_Desc;
	}

	public void setWorkLine_Desc(String workLine_Desc) {
		this.workLine_Desc = workLine_Desc;
	}

}
