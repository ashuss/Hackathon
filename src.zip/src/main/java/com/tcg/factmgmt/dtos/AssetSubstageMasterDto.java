package com.tcg.factmgmt.dtos;

public class AssetSubstageMasterDto {

	private String AssetSubstage_Id;
	private String Asset_Id;
	private String Substage_Id;
	private float Ideal_Time_SubStage;
	private float Operator_Buffer_Time;
	private float Ideal_Time_To_SubStage;

	public String getAssetSubstage_Id() {
		return AssetSubstage_Id;
	}

	public void setAssetSubstage_Id(String assetSubstage_Id) {
		AssetSubstage_Id = assetSubstage_Id;
	}

	public String getAsset_Id() {
		return Asset_Id;
	}

	public void setAsset_Id(String asset_Id) {
		Asset_Id = asset_Id;
	}

	public String getSubstage_Id() {
		return Substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		Substage_Id = substage_Id;
	}

	public float getIdeal_Time_SubStage() {
		return Ideal_Time_SubStage;
	}

	public void setIdeal_Time_SubStage(float ideal_Time_SubStage) {
		Ideal_Time_SubStage = ideal_Time_SubStage;
	}

	public float getOperator_Buffer_Time() {
		return Operator_Buffer_Time;
	}

	public void setOperator_Buffer_Time(float operator_Buffer_Time) {
		Operator_Buffer_Time = operator_Buffer_Time;
	}

	public float getIdeal_Time_To_SubStage() {
		return Ideal_Time_To_SubStage;
	}

	public void setIdeal_Time_To_SubStage(float ideal_Time_To_SubStage) {
		Ideal_Time_To_SubStage = ideal_Time_To_SubStage;
	}

}
