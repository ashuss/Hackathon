package com.tcg.factmgmt.dtos;

public class OperatorMasterDto {

	private String operatorId;
	private String stage_Id;
	private String substage_Id;
	private String operatorName;
	private String operatorContact;
	private String operatorShift;

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getStage_Id() {
		return stage_Id;
	}

	public void setStage_Id(String stage_Id) {
		this.stage_Id = stage_Id;
	}

	public String getSubstage_Id() {
		return substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		this.substage_Id = substage_Id;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getOperatorContact() {
		return operatorContact;
	}

	public void setOperatorContact(String operatorContact) {
		this.operatorContact = operatorContact;
	}

	public String getOperatorShift() {
		return operatorShift;
	}

	public void setOperatorShift(String operatorShift) {
		this.operatorShift = operatorShift;
	}

}
