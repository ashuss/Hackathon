package com.tcg.factmgmt.dtos;

public class PlantMasterDto {

	private String plant_Id;
	private String plant_Name;
	private String latitude;
	private String longitude;

	public String getPlant_Id() {
		return plant_Id;
	}

	public void setPlant_Id(String plant_Id) {
		this.plant_Id = plant_Id;
	}

	public String getPlant_Name() {
		return plant_Name;
	}

	public void setPlant_Name(String plant_Name) {
		this.plant_Name = plant_Name;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

}
