package com.tcg.factmgmt.dtos;

import java.security.Timestamp;




public class AssetTrackingTransactionalDto {

	private String assetTracking_Id;
	private String asset_Id;
	private String substage_Id;
	private Timestamp actual_In_Time;
	private Timestamp actual_Out_Time;
	private Timestamp operation_Start_time;
	private Timestamp operation_End_time;
	private Timestamp actual_To_SubStage_Time;
	private float subStage_Efficiency;
	private float operator_Efficiency;
	private String operatorId;

	public String getAssetTracking_Id() {
		return assetTracking_Id;
	}

	public void setAssetTracking_Id(String assetTracking_Id) {
		this.assetTracking_Id = assetTracking_Id;
	}

	public String getAsset_Id() {
		return asset_Id;
	}

	public void setAsset_Id(String asset_Id) {
		this.asset_Id = asset_Id;
	}

	public String getSubstage_Id() {
		return substage_Id;
	}

	public void setSubstage_Id(String substage_Id) {
		this.substage_Id = substage_Id;
	}

	public Timestamp getActual_In_Time() {
		return actual_In_Time;
	}

	public void setActual_In_Time(Timestamp actual_In_Time) {
		this.actual_In_Time = actual_In_Time;
	}

	public Timestamp getActual_Out_Time() {
		return actual_Out_Time;
	}

	public void setActual_Out_Time(Timestamp actual_Out_Time) {
		this.actual_Out_Time = actual_Out_Time;
	}

	public Timestamp getOperation_Start_time() {
		return operation_Start_time;
	}

	public void setOperation_Start_time(Timestamp operation_Start_time) {
		this.operation_Start_time = operation_Start_time;
	}

	public Timestamp getOperation_End_time() {
		return operation_End_time;
	}

	public void setOperation_End_time(Timestamp operation_End_time) {
		this.operation_End_time = operation_End_time;
	}

	public Timestamp getActual_To_SubStage_Time() {
		return actual_To_SubStage_Time;
	}

	public void setActual_To_SubStage_Time(Timestamp actual_To_SubStage_Time) {
		this.actual_To_SubStage_Time = actual_To_SubStage_Time;
	}

	public float getSubStage_Efficiency() {
		return subStage_Efficiency;
	}

	public void setSubStage_Efficiency(float subStage_Efficiency) {
		this.subStage_Efficiency = subStage_Efficiency;
	}

	public float getOperator_Efficiency() {
		return operator_Efficiency;
	}

	public void setOperator_Efficiency(float operator_Efficiency) {
		this.operator_Efficiency = operator_Efficiency;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

}
