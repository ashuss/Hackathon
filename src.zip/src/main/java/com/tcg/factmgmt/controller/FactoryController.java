package com.tcg.factmgmt.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class FactoryController {

}
