package com.tcg.factmgmt.repository;

public interface SubstageMasterRepository {

}
