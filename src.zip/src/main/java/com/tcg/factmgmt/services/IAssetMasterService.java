package com.tcg.factmgmt.services;

public interface IAssetMasterService {

}
